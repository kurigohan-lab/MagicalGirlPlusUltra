
Hooks.once("init", () => {
  console.log("Magical Girls Plus Ultra | Initializing");

  class MGPUMagicalGirlSheet extends ActorSheet {
    static get defaultOptions() {
      return foundry.utils.mergeObject(super.defaultOptions, {
        classes: ["mgpu", "sheet", "actor"],
        template: "systems/magical-girls-plus-ultra/templates/actor-sheet.html",
        width: 700,
        height: 800
      });
    }

    activateListeners(html) {
      super.activateListeners(html);

      html.find(".bonus").on("click", event => {
        const key = event.currentTarget.dataset.core;
        const bonus = this.actor.system.cores[key].bonus + 1;
        this.actor.update({[`system.cores.${key}.bonus`]: bonus});
      });

      html.find(".bonus").on("contextmenu", event => {
        event.preventDefault();
        const key = event.currentTarget.dataset.core;
        const bonus = this.actor.system.cores[key].bonus - 1;
        this.actor.update({[`system.cores.${key}.bonus`]: bonus});
      });

      html.find(".core-roll").on("click", async event => {
        const key = event.currentTarget.dataset.core;
        const core = this.actor.system.cores[key];
        const roll = await new Roll(`${core.die} + ${core.bonus}`).evaluate();

        const content = `
          <div class="mgpu-card">
            <h2>${key.toUpperCase()} CHECK</h2>
            <p>Magical Girl Plus Ultra</p>
            <hr>
            <strong>${roll.total}</strong>
          </div>`;

        ChatMessage.create({
          content,
          speaker: ChatMessage.getSpeaker({actor: this.actor})
        });
      });
    }
  }

  Actors.registerSheet("magical-girls-plus-ultra", MGPUMagicalGirlSheet, {
    types: ["magicalGirl"],
    makeDefault: true
  });
});
